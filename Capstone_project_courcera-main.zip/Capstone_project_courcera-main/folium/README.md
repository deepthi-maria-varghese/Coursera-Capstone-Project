# Workaround

Due to "Make this Notebook Trusted to load map: File -> Trust Notebook" error
I decided to create this folder with prints from my notebook, otherwise it would
take ever more time to solve the exhibition problem.


![01](01.png)   
![02](02.png)   
![03](03.png)   
![04](04.png)   
![05](05.png)   
![06](06.png)   
![07](07.png)   
![08](08.png)   
![09](09.png)   
![10](10.png)   
![11](11.png)   
![12](12.png)   
![13](13.png)   
![14](14.png)   
![15](15.png)   
![16](16.png)   
![17](17.png)   
![18](18.png)   